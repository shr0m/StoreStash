#!/bin/bash

# === Configuration ===
APP_DIR="/opt/StoreStash"  # Folder where your Flask app repo is
BRANCH="main"                     # Branch to track
SERVICE_NAME="SERVICE_NAME"       # systemd service name for your app
LOG_FILE="/var/log/update_StoreStash.log"

# === Start log entry ===
echo "[$(date)] Starting update check..." >> "$LOG_FILE"

cd "$APP_DIR" || {
    echo "[$(date)] ERROR: Could not enter app directory $APP_DIR" >> "$LOG_FILE"
    exit 1
}

# Make sure correct branch
git checkout "$BRANCH" >> "$LOG_FILE" 2>&1

# Fetch latest updates
git fetch origin >> "$LOG_FILE" 2>&1

# Check if local is behind remote
if git diff --quiet HEAD "origin/$BRANCH"; then
    echo "[$(date)] No updates found." >> "$LOG_FILE"
    exit 0
fi

echo "[$(date)] Updates found! Pulling changes..." >> "$LOG_FILE"
git pull origin "$BRANCH" >> "$LOG_FILE" 2>&1

# Check if requirements.txt changed
if git diff --name-only HEAD@{1} HEAD | grep -q "^requirements.txt$"; then
    echo "[$(date)] requirements.txt changed — installing dependencies..." >> "$LOG_FILE"
    pip install --upgrade -r requirements.txt >> "$LOG_FILE" 2>&1
fi

# Restart the Flask service
echo "[$(date)] Restarting service $SERVICE_NAME..." >> "$LOG_FILE"
systemctl restart "$SERVICE_NAME" >> "$LOG_FILE" 2>&1

echo "[$(date)] Update complete." >> "$LOG_FILE"